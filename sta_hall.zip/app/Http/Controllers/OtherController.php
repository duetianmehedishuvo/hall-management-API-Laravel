<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\SliderModel;
use App\Models\RunningTextModel;
use App\Models\OtherModel;

class OtherController extends Controller
{
    function addSliderImage(Request $request)
    {

        $fileData = $request->file('imageUrl');
        $reportNo = $request->input('reportNo');
        $reportImage = '';

        if ($fileData != null) {
            $imageUrl = $reportNo . '.' . $fileData->extension();
            $fileData->move('images', $imageUrl);
            $reportImage = $imageUrl;
        } else {
            $reportImage = 'no-image-found.jpg';
        }

        $result = SliderModel::insert(['imageUrl' => $reportImage]);

        if ($result == true) {
            return response()->json(['message' => 'Slider Added Successfully', 'statusCode' => 200])->setStatusCode(200);

        } else {
            return response()->json(['message' => 'Slider Added Failed', 'statusCode' => 404])->setStatusCode(404);
        }

    }


    function addSliderText(Request $request)
    {

        $text = $request->input('text');

        $result = RunningTextModel::insert(['text' => $text]);

        if ($result == true) {
            return response()->json(['message' => 'Slider Text Added Successfully', 'statusCode' => 200])->setStatusCode(200);

        } else {
            return response()->json(['message' => 'Slider Text Added Failed', 'statusCode' => 404])->setStatusCode(404);
        }
    }
    function getSlideAndText(Request $request)
    {
        $slideResults = SliderModel::all();
        $runningTextResults = RunningTextModel::all();
        return response()->json(['slideResults' => $slideResults, 'runningTextResults' => $runningTextResults])->setStatusCode(200);
    }

    
    function getSliderData(Request $request)
    {
        $slideResults = SliderModel::all();
        return response($slideResults);
    }

    function getRunningTextSliderData(Request $request)
    {
        $slideResults = RunningTextModel::all();
        return response($slideResults);
    }

    function deleteSliderText(Request $request)
    {
        $id = $request->input('id');

        $result = RunningTextModel::where('id', $id)->delete();
        if ($result == true) {
            return response()->json(['message' => 'Delete Success', 'statusCode' => 200])->setStatusCode(200);

        } else {
            return response()->json(['message' => 'Fail ! Try Again', 'statusCode' => 404])->setStatusCode(404);

        }
    }

    function deleteSliderImage(Request $request)
    {
        $id = $request->input('id');

        $result = SliderModel::where('id', $id)->delete();
        if ($result == true) {
            return response()->json(['message' => 'Delete Success', 'statusCode' => 200])->setStatusCode(200);
        } else {
            return response()->json(['message' => 'Fail ! Try Again', 'statusCode' => 404])->setStatusCode(404);

        }
    }


    function updateRunningTextInfo(Request $request)
    {
        $id = $request->input('id');
        $newText = $request->input('newText');
        $result = RunningTextModel::where('id', $id)->update(['text' => $newText]);

        if ($result == true) {
            return response()->json(['message' => 'Update Successfully', 'statusCode' => 200])->setStatusCode(200);

        } else {
            return response()->json(['message' => 'Fail ! Try Again', 'statusCode' => 404])->setStatusCode(404);

        }
    }

}